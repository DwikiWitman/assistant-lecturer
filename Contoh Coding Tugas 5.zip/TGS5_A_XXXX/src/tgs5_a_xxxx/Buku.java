/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tgs5_a_xxxx;

import java.util.ArrayList;

/**
 *
 * @author Yohanes Dwiki Witman
 */
public class Buku {
    int ISBN, jumlah_buku, tahun_terbit;
    String judul_buku, kategori_buku;
    double harga;
    public ArrayList<Penulis> penulis;
    public Editor editor;

    public Buku(int ISBN, int jumlah_buku, int tahun_terbit, String judul_buku, String kategori_buku, double harga, ArrayList<Penulis> penulis, Editor editor) {
        this.ISBN = ISBN;
        this.jumlah_buku = jumlah_buku;
        this.tahun_terbit = tahun_terbit;
        this.judul_buku = judul_buku;
        this.kategori_buku = kategori_buku;
        this.harga = harga;
        this.penulis = penulis;
        this.editor = editor;
    }

    public int getISBN() {
        return ISBN;
    }

    public int getJumlah_buku() {
        return jumlah_buku;
    }

    public int getTahun_terbit() {
        return tahun_terbit;
    }

    public String getJudul_buku() {
        return judul_buku;
    }

    public String getKategori_buku() {
        return kategori_buku;
    }

    public double getHarga() {
        return harga;
    }

    public void setEditor(Editor editor) {
        this.editor = editor;
    }
    
    public void addPenulis(Penulis penulis) {
        this.penulis.add(penulis);
    }

    public void setJumlah_buku(int jumlah_buku) {
        this.jumlah_buku = jumlah_buku;
    }
    
    public void showBuku() { 
        System.out.println("");
        System.out.println("----------== Data Buku ==-----------");
        System.out.println("");
        System.out.println("ISBN          : "+getISBN());
               
        System.out.println("----------== Data Penulis ==--------");
        for(int i=0;i<penulis.size();i++){
            System.out.println("---Penulis "+(i+1));
            penulis.get(i).showPenulis();
        }
        
        System.out.println("----------== Data Editor ==---------");
        editor.showEditor();
    }
    
}
