/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tgs5_a_xxxx;

/**
 *
 * @author Yohanes Dwiki Witman
 */
public class Editor extends Pekerja{
    int lama_bekerja; 
    String jabatan;

    public Editor() {
    }

    public Editor(int lama_bekerja, String jabatan, int nomor_identitas, int umur, int nomor_hp, String nama, String jenis_kelamin, double gaji) {
        super(nomor_identitas, umur, nomor_hp, nama, jenis_kelamin, gaji);
        this.lama_bekerja = lama_bekerja;
        this.jabatan = jabatan;
    }

    public int getLama_bekerja() {
        return lama_bekerja;
    }

    public String getJabatan() {
        return jabatan;
    }
    
    public void showEditor()
    {
        super.showPekerja();
        //panggil getter editor disini!
        //...
    }
}
