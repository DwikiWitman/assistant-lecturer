/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tgs5_a_xxxx;

/**
 *
 * @author Yohanes Dwiki Witman
 */
public class Penulis extends Pekerja {
    int jumlah_buku_dirilis; 
    String penghargaan;

    public Penulis(int jumlah_buku_dirilis, String penghargaan, int nomor_identitas, int umur, int nomor_hp, String nama, String jenis_kelamin, double gaji) {
        super(nomor_identitas, umur, nomor_hp, nama, jenis_kelamin, gaji);
        this.jumlah_buku_dirilis = jumlah_buku_dirilis;
        this.penghargaan = penghargaan;
    }

    public int getJumlah_buku_dirilis() {
        return jumlah_buku_dirilis;
    }

    public String getPenghargaan() {
        return penghargaan;
    }
    
    public void showPenulis()
    {
        super.showPekerja();
        //panggil getter penulis disini!
        //...
    }
}
