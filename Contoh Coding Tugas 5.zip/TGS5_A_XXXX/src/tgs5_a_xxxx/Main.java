/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tgs5_a_xxxx;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

/**
 *
 * @author Yohanes Dwiki Witman
 */
public class Main {
    ArrayList<Buku> buku = new ArrayList<>();  
    BufferedReader B = new BufferedReader(new InputStreamReader(System.in));
    
    //ATRIBUT TAMPUNG BUKU
    int jumlah_buku_dirilis = -1, nomor_identitas = 1, nomor_hp = -1, umur = -1, lama_bekerja = -1, idx=-1;
    String penghargaan = "-", nama = "-", jenis_kelamin = "-", jabatan = "-";
    double gaji = -1;
    
    //ATRIBUT TAMPUNG BUKU
    int ISBN = -1, jumlah_buku = -1, tahun_terbit = -1;
    String judul_buku = "-", kategori_buku = "-";
    double harga = -1;
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        int pil = -1;
        Main M = new Main();

        do {
            System.out.println("------------------== GramedV.1 ==-------------------");
            System.out.println("-METODE BUAT BUKU DULU BARU INPUT PENULIS & EDITOR-");
            System.out.println("1. Buat Data Buku");
            System.out.println("2. Isikan Penulis Buku");
            System.out.println("3. Isikan Editor Buku");
            System.out.println("4. Tampil Data Buku, Penulis Buku, dan Editor Buku");
            System.out.println("5. Edit Data Buku");
            System.out.println("6. Delete Data Buku");
            System.out.println("7. Transaksi Pembelian Buku");
            System.out.print("Pilihan: ");
            pil = Integer.parseInt(M.B.readLine());

            switch (pil) {
                case 1:
                    M.inputDataBuku();
                    break;
                case 2:
                    M.inputDataPenulis();
                    break;
                case 3:
                    M.inputDataEditor();
                    break;
                case 4:
                    M.showAll();
                    break;
                case 5:
                    //M.editDataBuku();
                    break;
                case 6:
                    //M.deleteDataBuku();
                    break;
                case 7:
                    //M.transaksiPembelianBuku();
                    break;
                default:
                    System.out.println("Pilihan hanya 1-7");
                    break;
            }
        } while (pil != 0);
    }
    
    private void inputDataBuku() throws IOException
    {
        clear();
        System.out.println("-=Input Data Buku=-");
        System.out.println("ISBN : ");ISBN=Integer.parseInt(B.readLine());
        System.out.println("Jumlah Buku : ");jumlah_buku=Integer.parseInt(B.readLine());
        // Coding inputan lain disini!
        // ...
        
        //BUAT OBJEK DAHULU TP KOSONGAN atau BELUM ADA DATANYA
        ArrayList<Penulis> penulis = new ArrayList<>();;
        Editor editor = new Editor();
        
        //passing data objek (msh null)
        Buku bk = new Buku(ISBN, jumlah_buku, tahun_terbit, judul_buku, kategori_buku, harga, penulis, editor);
        buku.add(bk);   
    }

    private void inputDataPenulis() throws IOException
    {
        clear();
        System.out.println("Masukkan ISBN :"); ISBN = Integer.parseInt(B.readLine()); idx = getIndexBuku(ISBN);
        if(idx != -1){
            System.out.println("-=Input Data Penulis=-");
            System.out.println("Nomor ID    : ");nomor_identitas=Integer.parseInt(B.readLine());
            System.out.println("Nama        : ");nama = B.readLine();
            // Coding inputan lain disini!
            // ...   

            Penulis p = new Penulis(jumlah_buku_dirilis, penghargaan, nomor_identitas, umur, nomor_hp, nama, jenis_kelamin, gaji);
            buku.get(idx).addPenulis(p);
        }else{
            System.out.println("ISBN Buku tidak ditemukan!");
        }
    }
    
    private void inputDataEditor() throws IOException
    {
        clear();
        System.out.println("Masukkan ISBN :"); ISBN = Integer.parseInt(B.readLine()); idx = getIndexBuku(ISBN);
        
        if(idx != -1){
            System.out.println("-=Input Data Editor=-");
            System.out.println("Nomor ID    : ");nomor_identitas=Integer.parseInt(B.readLine());
            System.out.println("Nama        : ");nama = B.readLine();
            // Coding inputan lain disini!
            // ...  

            Editor editor = new Editor(lama_bekerja, jabatan, nomor_identitas, umur, nomor_hp, nama, jenis_kelamin, gaji);
            buku.get(idx).setEditor(editor);
        } else{
            System.out.println("ISBN Buku tidak ditemukan!");
        }
        
    }
    
    private void deleteDataBuku() throws IOException{
        clear();
        System.out.println("Masukkan ISBN :"); ISBN = Integer.parseInt(B.readLine()); idx = getIndexBuku(ISBN);
        if(idx != -1){
            //object dot remove dalam kurung idx tutup kurung
            //...
            System.out.println("-=Buku berhasil didelete!=-");
        } else{
            System.out.println("ISBN Buku tidak ditemukan!");
        }
    }
    
    private void editDataBuku() throws IOException{
        clear();
        System.out.println("Masukkan ISBN :"); ISBN = Integer.parseInt(B.readLine()); idx = getIndexBuku(ISBN);
        if(idx != -1){
            System.out.println("-=Edit Data Buku=-");
            System.out.println("Jumlah Buku : "); jumlah_buku = Integer.parseInt(B.readLine());
            buku.get(idx).setJumlah_buku(jumlah_buku);
            // Coding inputan lain disini!
            // ...

        }else{
            System.out.println("ISBN Buku tidak ditemukan!");
        }
    }
    
    private void showAll() throws IOException
    {
        System.out.println("----------== Show Buku, Penulis, Editor ==----------");
        for(int i = 0;i<buku.size();i++){
            buku.get(i).showBuku();
        }
    }
    
    private int getIndexBuku(int isbn) {
        int i = 0;
        try {
            if (isEmptyBuku() != 1) {
                for (i = 0; i < buku.size(); i++) {
                    if (buku.get(i).getISBN() == isbn) {
                        return i;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return -1;
    }
    
    private int isEmptyBuku() {
        if (buku == null) {
            return 1;
        }
        return 0;
    }
    
    private void clear(){
        jumlah_buku_dirilis = -1; nomor_identitas = 1; nomor_hp = -1; umur = -1; lama_bekerja = -1; idx=-1;
        penghargaan = "-"; nama = "-"; jenis_kelamin = "-"; jabatan = "-";
        gaji = -1;

        ISBN = -1; jumlah_buku = -1; tahun_terbit = -1;
        judul_buku = "-"; kategori_buku = "-";
        harga = -1;
    }
       
}
