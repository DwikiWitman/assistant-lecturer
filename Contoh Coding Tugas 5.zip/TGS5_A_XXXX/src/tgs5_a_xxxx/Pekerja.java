/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tgs5_a_xxxx;

/**
 *
 * @author Yohanes Dwiki Witman
 */
public class Pekerja {
    int nomor_identitas, umur, nomor_hp;
    String nama, jenis_kelamin;
    double gaji;

    public Pekerja() {
    }

    public Pekerja(int nomor_identitas, int umur, int nomor_hp, String nama, String jenis_kelamin, double gaji) {
        this.nomor_identitas = nomor_identitas;
        this.umur = umur;
        this.nomor_hp = nomor_hp;
        this.nama = nama;
        this.jenis_kelamin = jenis_kelamin;
        this.gaji = gaji;
    }

    public int getNomor_identitas() {
        return nomor_identitas;
    }

    public int getUmur() {
        return umur;
    }

    public int getNomor_hp() {
        return nomor_hp;
    }

    public String getNama() {
        return nama;
    }

    public String getJenis_kelamin() {
        return jenis_kelamin;
    }

    public double getGaji() {
        return gaji;
    }
    
    public void showPekerja()
    {
        System.out.println("Id      : "+getNomor_identitas());
        System.out.println("Umur    : "+getUmur());
        System.out.println("HP      : "+getNomor_hp());
        System.out.println("Nama    : "+getNama());
        System.out.println("J Klmn  : "+getJenis_kelamin());
        System.out.println("Gaji    : "+getGaji());
    }
}
