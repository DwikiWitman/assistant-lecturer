/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ugd5_c_7748;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author Praktikan
 */
public class Team
{
    private String Nama, asal_universitas;
    private int jumlah_masakan;
    Mahasiswa[] Mhs;
    BufferedReader B = new BufferedReader(new InputStreamReader(System.in)); 
    
    public Team()
    {
    }

    public Team(String Nama, String asal_universitas, int jumlah_masakan, Mahasiswa[] Mhs)
    {
        this.Nama = Nama;
        this.asal_universitas = asal_universitas;
        this.jumlah_masakan = jumlah_masakan;
        this.Mhs = Mhs;
    }

    public void setNama(String Nama)
    {
        this.Nama = Nama;
    }

    public void setAsal_universitas(String asal_universitas)
    {
        this.asal_universitas = asal_universitas;
    }

    public void setJumlah_masakan(int jumlah_masakan)
    {
        this.jumlah_masakan = jumlah_masakan;
    }

    public String getNama()
    {
        return Nama;
    }

    public String getAsal_universitas()
    {
        return asal_universitas;
    }

    public int getJumlah_masakan()
    {
        return jumlah_masakan;
    }
    
    public void setMahasiswa(Mahasiswa[] M) {
        Mhs = M;
    }
    
    public void showTeam() {
        int i;
        
        System.out.println("");
        System.out.println("----------== DATA TEAM ==----------");
        System.out.println("");
        System.out.println("Nama Team: "+getNama());
        System.out.println("Asal Universitas: "+getAsal_universitas());
        System.out.println("Jumlah karya yang dikirim: "+getJumlah_masakan());
        
        if(getJumlah_masakan()>1)
            System.out.println("Biaya Lomba: "+((getJumlah_masakan()-1)*10000+50000));
        else
            System.out.println("Biaya Lomba: "+50000);   
        
        System.out.println("***DATA MAHASISWA DI TEAM "+getNama());
        for(i=0;i<3;i++){
            System.out.println("");
            Mhs[i].showMahasiswa();
        }
    }
    
    public void searchByName() throws IOException {
        int i;
        String nama2;
        System.out.println("***TUGAS MODUL 5****");
        System.out.println("Masukkan nama Mahasiswa yang akan dicari: ");
        nama2 = B.readLine();
        
        for(i=0;i<3;i++)
        {
            if(nama2.equals(Mhs[i].getNama()))
            {
                Mhs[i].showMahasiswa();
                break;
            }
        }
    }
    
}
