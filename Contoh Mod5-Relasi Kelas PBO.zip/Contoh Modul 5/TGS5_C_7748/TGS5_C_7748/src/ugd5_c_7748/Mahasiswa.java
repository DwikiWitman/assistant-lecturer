/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ugd5_c_7748;

/**
 *
 * @author Praktikan
 */
public class Mahasiswa
{
    private String Nama; 
    private int NPM; 
    private float IPK;

    public Mahasiswa()
    {
    }

    public Mahasiswa(String Nama, int NPM, float IPK)
    {
        this.Nama = Nama;
        this.NPM = NPM;
        this.IPK = IPK;
    }

    public void setIPK(float IPK)
    {
        this.IPK = IPK;
    }

    public void setNPM(int NPM)
    {
        this.NPM = NPM;
    }

    public void setNama(String Nama)
    {
        this.Nama = Nama;
    }

    public float getIPK()
    {
        return IPK;
    }

    public int getNPM()
    {
        return NPM;
    }

    public String getNama()
    {
        return Nama;
    }
    
    public void showMahasiswa() {
        System.out.println("Nama: "+getNPM());
        System.out.println("NPM: "+getNama());
        System.out.println("IPK: "+getIPK());
    }
}
