/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ugd5_c_7748;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author Praktikan
 */
public class Main
{
    BufferedReader B = new BufferedReader(new InputStreamReader(System.in)); 
    Team T = new Team();
    private final Mahasiswa[] Mhs = new Mahasiswa[3];
    
    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException
    {
        // TODO code application logic here
        Main M = new Main();
                
        M.inputDataTeam();
        M.inputDataMahasiswa();
        M.T.setMahasiswa(M.Mhs);
        M.T.showTeam(); 
        M.T.searchByName();
    }
    
    public void inputDataTeam() throws IOException {
        String Nama, asal_universitas;
        int jumlah_masakan, i;
   
        System.out.println("Masukkan Nama Team: ");
        Nama = B.readLine();
        System.out.println("Masukkan Asal Universitas: ");
        asal_universitas = B.readLine(); 
        System.out.println("Masukkan Jumlah Karya yang dikirim: ");
        jumlah_masakan = Integer.parseInt(B.readLine());
        T = new Team(Nama, asal_universitas, jumlah_masakan, Mhs);        
    }
    
    public void inputDataMahasiswa() throws IOException {
        String Nama; 
        int NPM, i; 
        float IPK;
        
        for(i=0;i<3;i++){
            System.out.println("----------== Mahasiswa "+(i+1)+"==----------");
            System.out.println("Masukkan Nama Mahasiswa: ");
            Nama = B.readLine();
            System.out.println("Masukkan NPM: ");
            NPM = Integer.parseInt(B.readLine());
            System.out.println("Masukkan IPK: ");
            IPK = Float.parseFloat(B.readLine());
            Mhs[i] = new Mahasiswa(Nama, NPM, IPK);
        }
    }
 
}
